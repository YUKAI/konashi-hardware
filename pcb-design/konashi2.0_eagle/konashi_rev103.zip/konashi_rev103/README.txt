file list:
 *.plc : Silk on components side
 *.stc : Solder resist on components side
 *.cmp : Components side copper
 *.sol : Solder side copper
 *.sts : Solder resist on solder side
 *.pls : Silk on solder side
 *.out : Outline

 *.dri : Drill information
 *.drd : Drill data

 *.gpi : report file

